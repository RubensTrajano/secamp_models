from datetime import datetime

from django.db import models

class User(models.Model):

    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=30)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)

class Contas(models.Model):

    id_conta = models.AutoField(primary_key=True)
    tp_conta = models.CharField(max_length=30)
    id_banco = models.IntegerField()
    banco = models.CharField(max_length=50)
    conta = models.IntegerField()
    agencia = models.IntegerField()
    operacao = models.IntegerField()

class Ufs(models.Model):

    id_uf = models.AutoField(primary_key=True)
    nome_uf = models.CharField(max_length=30)
    sigla_uf = models.CharField(max_length=2)

class Cidade(models.Model):

    id_cidade = models.AutoField(primary_key=True)
    nome_cidade = models.CharField(max_length=50)
    id_uf = models.ForeignKey(Ufs, on_delete=models.CASCADE)


class Enderecos(models.Model):

    id_endereco = models.AutoField(primary_key=True)
    id_cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE)
    logradouro = models.CharField(max_length=150)
    numero = models.CharField(max_length=8)
    cep = models.CharField(max_length=10)
    bairro = models.CharField(max_length=80)
    complemento = models.CharField(max_length=60)
    observacoes = models.TextField()

class Pessoas(models.Model):

    id_pessoa = models.AutoField(primary_key=True)
    vinculo = models.CharField(max_length=20)
    id_user = models.ForeignKey(User, on_delete=models.CASCADE)
    cpd = models.IntegerField()
    nome = models.CharField(max_length=200)
    telefone = models.CharField(max_length=16)
    email = models.CharField(max_length=200)
    id_endereco = models.ForeignKey(Enderecos, on_delete=models.CASCADE)
    id_conta = models.ForeignKey(Contas, on_delete=models.CASCADE)


class Ocorrencias(models.Model):
    id_ocorrencia = models.AutoField(primary_key=True)
    data = models.DateField(default=datetime.now)
    realizada = models.CharField(max_length=1)
    ocorrencia = models.CharField(max_length=1)
    id_pessoas = models.ForeignKey(Pessoas, on_delete=models.CASCADE)










#user = models.OneToOneField(User, on_delete=models.PROTECT) #func so tem uma ligacao
#    departamentos = models.ManyToManyField(Departamento) #criar list

